// 富文本编辑器
var ue = UE.getEditor('editor', {
    toolbars: [
        [  'source','undo','bold', 'italic', 'strikethrough', 'fontfamily','fontsize',  'forecolor','horizontal',  'blockquote','insertorderedlist',  'insertunorderedlist','indent','justifyleft','justifyright','justifycenter','justifyjustify','imagecenter','lineheight','link', 'simpleupload', 'insertimage','music','insertvideo','spechars','inserttable','autotypeset','removeformat', 'preview',]
    ],
    autoHeightEnabled: true,
    autoFloatEnabled: true
});

