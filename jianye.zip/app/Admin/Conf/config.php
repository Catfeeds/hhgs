<?php
return array(
	//'配置项'=>'配置值'
	
	/*模版设置*/
	// 设置模版的默认路径
	'VIEW_PATH'				=>'./ThemeAdmin/',
	/*模版主题设置*/
);