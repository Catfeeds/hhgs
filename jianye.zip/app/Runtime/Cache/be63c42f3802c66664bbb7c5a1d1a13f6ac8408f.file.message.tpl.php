<?php /* Smarty version Smarty-3.1.6, created on 2018-01-08 18:37:33
         compiled from "/alidata/www/api/jianye_garden/Theme/default/tpl/message.tpl" */ ?>
<?php /*%%SmartyHeaderCode:11467446395a5349ed0d68f3-18218263%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'be63c42f3802c66664bbb7c5a1d1a13f6ac8408f' => 
    array (
      0 => '/alidata/www/api/jianye_garden/Theme/default/tpl/message.tpl',
      1 => 1515051630,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11467446395a5349ed0d68f3-18218263',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5a5349ed1118b',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a5349ed1118b')) {function content_5a5349ed1118b($_smarty_tpl) {?><style type="text/css">
	.message_cover{
		position: fixed;
		top: 0;
		left: 0;
		background-color: rgba(0,0,0,0.3);
		width: 100%;
		height: 100%;
		display: none;
	}
	.message_box{
		position: relative;
		width: 85%;
		min-height: 160px;
		background-color: #fff;
		margin:80px auto;
		border-radius: 5px;
		padding: 20px ;
		text-align: center;
		color: rgb(207,166,108);
	}
	.message_box img{
		width: 180px;
	}
	.message_box .content{
		min-height: 90px;
		padding: 20px;
		/*font-size: 14px;*/

	}
	.message_box .btns{
		position: absolute;
		left: 50%;
		margin-left: -52px;
		bottom: 20px;
	}
	.message_box .btns button{
		background: -webkit-linear-gradient(left, rgb(207,166,108), rgb(238,210,170));
		padding: 6px 40px;
		color: #fff;
	}
</style>
<div class='message_cover'>
	<div class='message_box'>
		<p id='img'></p>
		<div class='content'></div>
		<p class='btns'>
			<button id='message_close'>确认</button>
		</p>
	</div>
</div>
<script type="text/javascript">
	$(function(){
		$('#message_close').click(function(){
			$('.message_cover').hide();
		});
	});
</script><?php }} ?>