<?php /* Smarty version Smarty-3.1.6, created on 2018-01-08 14:32:44
         compiled from "/alidata/www/api/jianye_garden/ThemeAdmin/default/tpl/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:3684249435a53108cd3a9a0-93479101%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a9e8b380cc50acca909bb76dfb31b2f452a22f3b' => 
    array (
      0 => '/alidata/www/api/jianye_garden/ThemeAdmin/default/tpl/footer.tpl',
      1 => 1515038223,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3684249435a53108cd3a9a0-93479101',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5a53108cd59fd',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a53108cd59fd')) {function content_5a53108cd59fd($_smarty_tpl) {?>	</div><!--/container-->
		<div class="clearfix"></div>

				
		<!-- start: JavaScript-->
		<script src="<?php echo @ORG;?>
boot/bootstrap.min.js"></script>	
		<!-- theme scripts -->
		<script src="<?php echo @THEMEADMIN;?>
assets/js/SmoothScroll.js"></script>
		<script src="<?php echo @THEMEADMIN;?>
assets/js/jquery.mmenu.min.js"></script>
		<script src="<?php echo @THEMEADMIN;?>
assets/js/core.min.js"></script>			
		<!-- end: JavaScript-->	
	</body>
</html><?php }} ?>