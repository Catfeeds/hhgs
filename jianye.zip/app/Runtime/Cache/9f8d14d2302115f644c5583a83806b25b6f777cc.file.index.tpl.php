<?php /* Smarty version Smarty-3.1.6, created on 2018-01-08 16:34:14
         compiled from "./Theme/default/Service/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:12496087175a532d065566b6-68136874%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9f8d14d2302115f644c5583a83806b25b6f777cc' => 
    array (
      0 => './Theme/default/Service/index.tpl',
      1 => 1515051630,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12496087175a532d065566b6-68136874',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'list' => 0,
    'item' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5a532d06634a8',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a532d06634a8')) {function content_5a532d06634a8($_smarty_tpl) {?><!DOCTYPE html>
<html lang='zh'>
<head>
	<title>服务</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no,maximum-scale=1.0">
	<link rel="stylesheet" type="text/css" href="<?php echo @THEME;?>
Service/css/index.css">
</head>
<body>
	<div class='container'>
		<div class='list'>
			<?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['list']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value){
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
				<a href="<?php echo @HOME;?>
Service/order.html?uid=<?php echo $_smarty_tpl->tpl_vars['item']->value['uid'];?>
">
					<div class='item'>
						<img src="<?php echo @UPLOAD;?>
service/<?php echo $_smarty_tpl->tpl_vars['item']->value['img'];?>
">
						<div class='icon'>
							<?php if ($_smarty_tpl->tpl_vars['item']->value['status']==1){?>
								<img src="<?php echo @THEME;?>
Service/img/open.png">
							<?php }else{ ?>
								<img src="<?php echo @THEME;?>
Service/img/close.png">
							<?php }?>
						</div>
					</div>
				</a>
			<?php } ?>
		</div>
		<div class='more'>
			<img src="<?php echo @THEME;?>
Service/img/more.png">
			<p>更多服务陆续更新中!</p>
		</div>
	</div>
</body>
</html><?php }} ?>